package com.podcastplanner.agent;

import com.podcastplanner.config.EpamDialConfig;
import com.podcastplanner.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ScriptAgentTest {

    private EpisodeContext sampleContext;
    private ScriptAgent agent;

    @BeforeEach
    void setUp() {
        // Config with empty API key → forces fallback
        EpamDialConfig config = new EpamDialConfig();
        // Use reflection-free approach: create a test-friendly config
        agent = new ScriptAgent(createTestConfig(""));

        sampleContext = EpisodeContext.builder()
                .titleHint("AI in Healthcare: Hope or Hype?")
                .angle("Exploring real-world impact of AI on diagnostics")
                .keywords(List.of("medical AI", "diagnostic imaging", "healthcare ethics"))
                .constraints(List.of("conversational tone", "college-student audience", "10 min total"))
                .guestIntroLine("Dr. Meera Sharma is an AI Research Lead at Apollo Hospitals who led India's first FDA-approved AI radiology tool.")
                .segmentPlan(List.of(
                        SegmentPlan.builder().name("Opening").minutes(2).objective("Hook the audience and introduce the guest").build(),
                        SegmentPlan.builder().name("Deep Dive").minutes(5).objective("Explore AI diagnostic accuracy and patient trust").build(),
                        SegmentPlan.builder().name("Closing").minutes(3).objective("Summarize key takeaways and inspire career interest").build()
                ))
                .build();
    }

    private EpamDialConfig createTestConfig(String apiKey) {
        return new EpamDialConfig() {
            @Override public String getUrl() { return "https://ai-proxy.lab.epam.com/openai/deployments/gpt-4o/chat/completions"; }
            @Override public String getApiKey() { return apiKey; }
            @Override public String getModel() { return "gpt-4o"; }
            @Override public double getTemperature() { return 0.8; }
            @Override public int getMaxTokens() { return 3000; }
        };
    }

    // Test 1: fallback returns valid ScriptOutput
    @Test
    void testFallbackReturnsValidScriptOutput() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        assertNotNull(result);
        assertEquals(sampleContext.getTitleHint(), result.getEpisodeTitle());
    }

    // Test 2: intro contains timestamps and speaker labels
    @Test
    void testFallbackIntroHasTimestampsAndLabels() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        assertTrue(result.getIntro().contains("[00:00] Host:"));
        assertTrue(result.getIntro().contains("Dr. Meera Sharma"));
        assertTrue(result.getIntro().contains("medical AI"));
    }

    // Test 3: outro contains timestamps, CTA, and goodbye
    @Test
    void testFallbackOutroHasRequiredParts() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        assertTrue(result.getOutro().contains("Host:"));
        assertTrue(result.getOutro().toLowerCase().contains("subscribe"));
        assertTrue(result.getOutro().toLowerCase().contains("next time"));
    }

    // Test 4: segment count matches segment_plan
    @Test
    void testFallbackSegmentCountMatchesPlan() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        assertEquals(sampleContext.getSegmentPlan().size(), result.getSegments().size());
        for (int i = 0; i < result.getSegments().size(); i++) {
            assertEquals(sampleContext.getSegmentPlan().get(i).getName(), result.getSegments().get(i).getName());
        }
    }

    // Test 5: estimated_duration equals sum of segment minutes
    @Test
    void testFallbackEstimatedDuration() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        int expected = sampleContext.getSegmentPlan().stream().mapToInt(SegmentPlan::getMinutes).sum();
        assertEquals(expected, result.getEstimatedDuration());
    }

    // Test 6: host_lines contain timestamps and speaker labels
    @Test
    void testFallbackLinesHaveTimestampsAndSpeakers() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        for (ScriptSegment seg : result.getSegments()) {
            for (String line : seg.getHostLines()) {
                assertTrue(line.contains("] Host:") || line.contains("] Guest:"),
                        "Missing speaker label: " + line);
                assertTrue(line.startsWith("["), "Missing timestamp: " + line);
            }
        }
    }

    // Test 7: segments have both Host and Guest lines
    @Test
    void testFallbackHasHostAndGuestLines() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        List<String> allLines = result.getSegments().stream()
                .flatMap(s -> s.getHostLines().stream())
                .toList();
        long hostCount = allLines.stream().filter(l -> l.contains("Host:")).count();
        long guestCount = allLines.stream().filter(l -> l.contains("Guest:")).count();
        assertTrue(hostCount > 0, "No host lines found");
        assertTrue(guestCount > 0, "No guest lines found");
    }

    // Test 8: parseLlmResponse handles fenced JSON
    @Test
    void testParseLlmResponseWithFences() throws Exception {
        String raw = "```json\n{\"episode_title\": \"Test\", \"intro\": \"Hi\", \"segments\": [], \"outro\": \"Bye\", \"estimated_duration\": 10}\n```";
        ScriptOutput parsed = agent.parseLlmResponse(raw);
        assertEquals("Test", parsed.getEpisodeTitle());
    }

    @Test
    void testParseLlmResponsePlainJson() throws Exception {
        String raw = "{\"episode_title\": \"Test\", \"intro\": \"Hi\", \"segments\": [], \"outro\": \"Bye\", \"estimated_duration\": 10}";
        ScriptOutput parsed = agent.parseLlmResponse(raw);
        assertEquals("Test", parsed.getEpisodeTitle());
    }

    // Test 9: run() uses fallback without API key
    @Test
    void testRunUsesFallbackWithoutApiKey() {
        ScriptAgent noKeyAgent = new ScriptAgent(createTestConfig(""));
        ScriptOutput result = noKeyAgent.run(sampleContext);
        assertNotNull(result);
        assertEquals(3, result.getSegments().size());
    }

    // Test 10: buildSystemPrompt includes context and format instructions
    @Test
    void testBuildSystemPromptIncludesContext() {
        String prompt = agent.buildSystemPrompt(sampleContext);
        assertTrue(prompt.contains(sampleContext.getTitleHint()));
        assertTrue(prompt.contains(sampleContext.getAngle()));
        assertTrue(prompt.contains("medical AI"));
        assertTrue(prompt.contains("[MM:SS]"));
        assertTrue(prompt.contains("Host"));
        assertTrue(prompt.contains("Guest"));
    }

    // Test 11: transitions have timestamps
    @Test
    void testFallbackTransitionsHaveTimestamps() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        for (ScriptSegment seg : result.getSegments()) {
            assertTrue(seg.getTransition().startsWith("["),
                    "Transition missing timestamp: " + seg.getTransition());
            assertTrue(seg.getTransition().contains("Host:"));
        }
    }

    // Test 12: Q&A placeholders are present
    @Test
    void testFallbackContainsQaPlaceholders() {
        ScriptOutput result = agent.generateFallback(sampleContext);
        List<String> allLines = result.getSegments().stream()
                .flatMap(s -> s.getHostLines().stream())
                .toList();
        String allText = String.join("\n", allLines);
        assertTrue(allText.contains(ScriptAgent.QA_PLACEHOLDER_WARMUP), "Missing warmup placeholder");
        assertTrue(allText.contains(ScriptAgent.QA_PLACEHOLDER_DEEP_DIVE), "Missing deep_dive placeholder");
        assertTrue(allText.contains(ScriptAgent.QA_PLACEHOLDER_CLOSING), "Missing closing placeholder");
        assertTrue(allText.contains(ScriptAgent.QA_PLACEHOLDER_RAPID_FIRE), "Missing rapid_fire placeholder");
    }
}


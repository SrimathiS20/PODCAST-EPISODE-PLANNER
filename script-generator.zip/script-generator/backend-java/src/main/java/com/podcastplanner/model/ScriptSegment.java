package com.podcastplanner.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScriptSegment {

    @JsonProperty("name")
    private String name;

    @JsonProperty("host_lines")
    private List<String> hostLines;

    @JsonProperty("transition")
    private String transition;
}


package com.podcastplanner.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SegmentPlan {

    @JsonProperty("name")
    private String name;

    @JsonProperty("minutes")
    private int minutes;

    @JsonProperty("objective")
    private String objective;
}


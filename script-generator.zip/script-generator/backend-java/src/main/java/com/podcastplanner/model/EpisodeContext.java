package com.podcastplanner.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EpisodeContext {

    @JsonProperty("title_hint")
    private String titleHint;

    @JsonProperty("angle")
    private String angle;

    @JsonProperty("keywords")
    private List<String> keywords;

    @JsonProperty("constraints")
    private List<String> constraints;

    @JsonProperty("guest_intro_line")
    private String guestIntroLine;

    @JsonProperty("segment_plan")
    private List<SegmentPlan> segmentPlan;
}


package com.podcastplanner.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.podcastplanner.config.EpamDialConfig;
import com.podcastplanner.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class ScriptAgent {

    private static final Logger logger = LoggerFactory.getLogger(ScriptAgent.class);

    // Q&A placeholder markers (filled by QuestionBankAgent at integration time)
    public static final String QA_PLACEHOLDER_WARMUP = "{{QUESTION_BANK:warmup}}";
    public static final String QA_PLACEHOLDER_DEEP_DIVE = "{{QUESTION_BANK:deep_dive}}";
    public static final String QA_PLACEHOLDER_CLOSING = "{{QUESTION_BANK:closing}}";
    public static final String QA_PLACEHOLDER_RAPID_FIRE = "{{QUESTION_BANK:rapid_fire}}";

    private final EpamDialConfig config;
    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    public ScriptAgent(EpamDialConfig config) {
        this.config = config;
        this.webClient = WebClient.builder().build();
        this.objectMapper = new ObjectMapper();
    }

    // -- For testing: allow injecting a custom WebClient --
    ScriptAgent(EpamDialConfig config, WebClient webClient) {
        this.config = config;
        this.webClient = webClient;
        this.objectMapper = new ObjectMapper();
    }

    // -----------------------------------------------------------------------
    // Timestamp helper
    // -----------------------------------------------------------------------

    static String ts(int minutes, int seconds) {
        return String.format("[%02d:%02d]", minutes, seconds);
    }

    static String ts(int minutes) {
        return ts(minutes, 0);
    }

    // -----------------------------------------------------------------------
    // Prompt builders
    // -----------------------------------------------------------------------

    public String buildSystemPrompt(EpisodeContext ctx) {
        String segmentsDesc = ctx.getSegmentPlan().stream()
                .map(s -> "  - " + s.getName() + " (" + s.getMinutes() + " min): " + s.getObjective())
                .collect(Collectors.joining("\n"));

        return "You are a world-class podcast script writer. Generate a complete, broadcast-ready\n" +
                "podcast episode script in JSON format.\n\n" +
                "EPISODE CONTEXT\n" +
                "- Title hint: " + ctx.getTitleHint() + "\n" +
                "- Angle: " + ctx.getAngle() + "\n" +
                "- Keywords: " + String.join(", ", ctx.getKeywords()) + "\n" +
                "- Constraints: " + String.join(", ", ctx.getConstraints()) + "\n" +
                "- Guest intro line: " + ctx.getGuestIntroLine() + "\n" +
                "- Segments:\n" + segmentsDesc + "\n\n" +
                "SCRIPT FORMAT RULES\n" +
                "1. Every line in host_lines must start with a timestamp and speaker label:\n" +
                "   \"[MM:SS] Host: ...\" or \"[MM:SS] Guest: ...\"\n" +
                "2. Timestamps must be sequential and realistic for the segment duration.\n" +
                "3. Alternate between Host and Guest naturally — this is a conversation, not a monologue.\n" +
                "4. Be fun, engaging, and natural — use humor, rhetorical questions, surprise facts.\n" +
                "5. Sound like real humans with natural filler (\"So,\", \"Here's the thing—\", \"Now,\", \"You know,\").\n" +
                "6. Each segment should have 4-8 dialogue lines proportional to its duration.\n" +
                "7. Intro must contain a hook, the guest introduction, and a preview of what's coming.\n" +
                "8. Outro must contain a summary, a call-to-action, and a goodbye.\n" +
                "9. Transition lines should flow smoothly between segments.\n" +
                "10. Language complexity must match the audience described in constraints.\n" +
                "11. Estimated duration should equal the sum of segment minutes.\n\n" +
                "Q&A INTEGRATION\n" +
                "- The script must include a Q&A segment where the Host asks the Guest questions.\n" +
                "- Use these EXACT placeholders where questions should be inserted (they will be\n" +
                "  replaced at runtime with actual questions from the QuestionBankAgent):\n" +
                "    " + QA_PLACEHOLDER_WARMUP + "   — easy warmup/icebreaker questions\n" +
                "    " + QA_PLACEHOLDER_DEEP_DIVE + " — in-depth technical/topic questions\n" +
                "    " + QA_PLACEHOLDER_CLOSING + "   — reflective wrap-up questions\n" +
                "    " + QA_PLACEHOLDER_RAPID_FIRE + " — quick rapid-fire fun questions\n" +
                "- Place warmup placeholders in the Opening segment.\n" +
                "- Place deep_dive placeholders in the Deep Dive segment.\n" +
                "- Place closing and rapid_fire placeholders in the Closing segment.\n" +
                "- Around each placeholder, write natural Host dialogue introducing the question,\n" +
                "  and a Guest placeholder response like \"[MM:SS] Guest: (Guest answers here)\".\n\n" +
                "Respond with ONLY valid JSON (no markdown fences, no extra text) matching this schema:\n" +
                "{\n" +
                "  \"episode_title\": \"string\",\n" +
                "  \"intro\": \"string (with [MM:SS] Host: and [MM:SS] Guest: labels)\",\n" +
                "  \"segments\": [\n" +
                "    {\n" +
                "      \"name\": \"string\",\n" +
                "      \"host_lines\": [\"[MM:SS] Speaker: line\", ...],\n" +
                "      \"transition\": \"[MM:SS] Host: transition line\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"outro\": \"string (with [MM:SS] Host: labels)\",\n" +
                "  \"estimated_duration\": number\n" +
                "}";
    }

    public String buildUserPrompt(EpisodeContext ctx) {
        int total = ctx.getSegmentPlan().stream().mapToInt(SegmentPlan::getMinutes).sum();
        return "Generate a " + total + "-minute podcast script for an episode titled \"" +
                ctx.getTitleHint() + "\" with " + ctx.getSegmentPlan().size() + " segments. " +
                "The angle is: " + ctx.getAngle() + ". " +
                "Include timestamps [MM:SS], speaker labels (Host/Guest), and natural dialogue. Go!";
    }

    // -----------------------------------------------------------------------
    // Response parsing
    // -----------------------------------------------------------------------

    public ScriptOutput parseLlmResponse(String raw) throws Exception {
        String text = raw.trim();
        // Strip ```json ... ``` fences
        Pattern pattern = Pattern.compile("```(?:json)?\\s*([\\s\\S]*?)```");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            text = matcher.group(1).trim();
        }
        return objectMapper.readValue(text, ScriptOutput.class);
    }

    // -----------------------------------------------------------------------
    // Deterministic fallback
    // -----------------------------------------------------------------------

    public ScriptOutput generateFallback(EpisodeContext ctx) {
        List<SegmentPlan> plans = ctx.getSegmentPlan();
        int totalMinutes = plans.stream().mapToInt(SegmentPlan::getMinutes).sum();

        int segStart = 0;
        List<ScriptSegment> segments = new ArrayList<>();

        for (int i = 0; i < plans.size(); i++) {
            SegmentPlan sp = plans.get(i);
            int m = segStart;
            List<String> lines = new ArrayList<>();
            String kw0 = ctx.getKeywords().isEmpty() ? "an amazing topic" : ctx.getKeywords().get(0);
            String kw1 = ctx.getKeywords().size() > 1 ? ctx.getKeywords().get(1) : "trust";
            String kw2 = ctx.getKeywords().size() > 2 ? ctx.getKeywords().get(2) : "transparency and education";

            if (i == 0) {
                // Opening segment — warmup Q&A
                lines.add(ts(m) + " Host: Alright, let's kick things off! So today we're diving into " + kw0 + " — and trust me, this one's going to blow your mind.");
                lines.add(ts(m, 30) + " Host: " + ctx.getGuestIntroLine());
                lines.add(ts(m + 1) + " Guest: Thanks so much for having me! I've been really looking forward to this conversation.");
                lines.add(ts(m + 1, 30) + " Host: Before we jump into the heavy stuff, let's warm up a bit. Here's a fun one —");
                lines.add(ts(m + 1, 45) + " Host: " + QA_PLACEHOLDER_WARMUP);
                lines.add(ts(m + 2) + " Guest: (Guest answers warmup question here)");
                if (sp.getMinutes() >= 5) {
                    lines.add(ts(m + 3) + " Host: I love that! Okay, now I'm even more excited to get into this — " + sp.getObjective().toLowerCase() + ".");
                }
            } else if (sp.getName().toLowerCase().contains("deep") || sp.getName().toLowerCase().contains("dive") || sp.getMinutes() >= 10) {
                // Deep dive segment — deep dive Q&A
                lines.add(ts(m) + " Host: Now, let's get into the heart of it — " + sp.getObjective().toLowerCase() + ".");
                lines.add(ts(m + 1) + " Guest: Absolutely. So here's the thing — when we talk about " + kw0 + ", most people don't realize how much has changed in just the last few years.");
                lines.add(ts(m + 2) + " Host: Right, and that's what's so wild. Let me hit you with a big one —");
                lines.add(ts(m + 2, 15) + " Host: " + QA_PLACEHOLDER_DEEP_DIVE);
                lines.add(ts(m + 3) + " Guest: (Guest answers deep dive question here)");
                lines.add(ts(m + 5) + " Host: Okay, that gives me chills. But let's play devil's advocate for a second — what are the risks?");
                lines.add(ts(m + 6, 30) + " Guest: Great question. The biggest concern is " + kw1 + ", and honestly, it's a valid one.");
                lines.add(ts(m + 8) + " Host: So how do we solve that? What's the path forward?");
                lines.add(ts(m + 9, 30) + " Guest: It comes down to " + kw2 + ". We need everyone at the table — not just the tech folks.");
                if (sp.getMinutes() >= 12) {
                    lines.add(ts(m + 11) + " Host: That's such an important point. And for anyone listening who wants to get involved — what would you tell them?");
                    lines.add(ts(m + 12) + " Guest: Start learning now. The field is wide open and we need fresh perspectives desperately.");
                }
            } else {
                // Closing / other segments — closing + rapid fire Q&A
                lines.add(ts(m) + " Host: Alright, we're heading into the final stretch here — " + sp.getObjective().toLowerCase() + ".");
                lines.add(ts(m, 30) + " Host: Before we wrap up, I've got a reflective one for you —");
                lines.add(ts(m, 45) + " Host: " + QA_PLACEHOLDER_CLOSING);
                lines.add(ts(m + 1) + " Guest: (Guest answers closing question here)");
                lines.add(ts(m + 2) + " Host: Beautifully said. And I think that's what makes this topic so relevant right now.");
                lines.add(ts(m + 2, 30) + " Host: Okay, now let's have some fun — rapid fire round! Quick answers only!");
                lines.add(ts(m + 2, 45) + " Host: " + QA_PLACEHOLDER_RAPID_FIRE);
                lines.add(ts(m + 3) + " Guest: (Guest answers rapid fire questions here)");
                if (sp.getMinutes() >= 8) {
                    lines.add(ts(m + 5) + " Host: Any resources or next steps you'd recommend for our listeners?");
                    lines.add(ts(m + 6) + " Guest: Definitely! I'd say start with " + kw0 + " — there are some great free courses out there. And follow the research, it moves fast!");
                }
            }

            String transition;
            if (i < plans.size() - 1) {
                transition = ts(segStart + sp.getMinutes() - 1) + " Host: Love it. Now, let's shift gears and move into " + plans.get(i + 1).getName() + ".";
            } else {
                transition = ts(segStart + sp.getMinutes() - 1) + " Host: And that brings us to the end of today's show.";
            }

            segments.add(ScriptSegment.builder()
                    .name(sp.getName())
                    .hostLines(lines)
                    .transition(transition)
                    .build());
            segStart += sp.getMinutes();
        }

        String kwPreview = ctx.getKeywords().stream().limit(3).collect(Collectors.joining(", "));

        String intro = ts(0) + " Host: Hey everyone! Welcome back to the show — you're in for a treat today. " +
                "We're tackling a topic that's literally changing the world as we speak: " + ctx.getTitleHint() + ". " +
                ctx.getGuestIntroLine() + " " +
                "Today we'll be covering " + kwPreview + ". " +
                "Stick around — you seriously don't want to miss this one!";

        String outro = ts(totalMinutes - 2) + " Host: And that's a wrap on today's episode — " + ctx.getTitleHint() + ". " +
                "Huge thanks to our incredible guest for dropping so much knowledge today. " +
                ts(totalMinutes - 1) + " Host: If you enjoyed this, smash that subscribe button, leave us a review, " +
                "and share it with someone who needs to hear this. " +
                ts(totalMinutes - 1, 30) + " Host: Until next time — keep learning, keep questioning, and stay curious. Peace!";

        return ScriptOutput.builder()
                .episodeTitle(ctx.getTitleHint())
                .intro(intro)
                .segments(segments)
                .outro(outro)
                .estimatedDuration(totalMinutes)
                .build();
    }

    // -----------------------------------------------------------------------
    // EPAM Dial caller
    // -----------------------------------------------------------------------

    public Mono<ScriptOutput> callEpamDial(EpisodeContext ctx) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("model", config.getModel());
        payload.put("temperature", config.getTemperature());
        payload.put("max_tokens", config.getMaxTokens());
        payload.put("messages", List.of(
                Map.of("role", "system", "content", buildSystemPrompt(ctx)),
                Map.of("role", "user", "content", buildUserPrompt(ctx))
        ));

        return webClient.post()
                .uri(config.getUrl())
                .header("Content-Type", "application/json")
                .header("api-key", config.getApiKey())
                .bodyValue(payload)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(60))
                .map(responseBody -> {
                    try {
                        JsonNode root = objectMapper.readTree(responseBody);
                        String rawContent = root.path("choices").get(0)
                                .path("message").path("content").asText();
                        logger.info("Raw LLM response length: {}", rawContent.length());
                        return parseLlmResponse(rawContent);
                    } catch (Exception e) {
                        logger.error("Parse error. Raw response: {}", responseBody);
                        throw new RuntimeException("Failed to parse EPAM Dial response", e);
                    }
                });
    }

    // -----------------------------------------------------------------------
    // Main run method
    // -----------------------------------------------------------------------

    public ScriptOutput run(EpisodeContext ctx) {
        if (config.getApiKey() == null || config.getApiKey().isBlank()) {
            logger.warn("EPAM_DIAL_API_KEY not set — using fallback script generator.");
            return generateFallback(ctx);
        }

        try {
            return callEpamDial(ctx).block();
        } catch (Exception exc) {
            logger.error("EPAM Dial call failed ({}) — using fallback.", exc.getMessage());
            return generateFallback(ctx);
        }
    }
}


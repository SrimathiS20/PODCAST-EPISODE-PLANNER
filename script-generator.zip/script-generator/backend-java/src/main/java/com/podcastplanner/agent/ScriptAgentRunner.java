package com.podcastplanner.agent;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.podcastplanner.config.EpamDialConfig;
import com.podcastplanner.model.*;

import java.util.List;

/**
 * Standalone runner to test the ScriptAgent and print the generated script.
 */
public class ScriptAgentRunner {

    public static void main(String[] args) throws Exception {
        EpamDialConfig config = new EpamDialConfig() {
            @Override public String getUrl() { return "https://ai-proxy.lab.epam.com/openai/deployments/gpt-4o/chat/completions"; }
            @Override public String getApiKey() { return "dial-26y4b3b2wk8vyoa8pmzywj1npjr"; }
            @Override public String getModel() { return "gpt-4o"; }
            @Override public double getTemperature() { return 0.8; }
            @Override public int getMaxTokens() { return 3000; }
        };

        EpisodeContext ctx = EpisodeContext.builder()
                .titleHint("AI in Healthcare: Hope or Hype?")
                .angle("Exploring real-world impact of AI on diagnostics")
                .keywords(List.of("medical AI", "diagnostic imaging", "healthcare ethics"))
                .constraints(List.of("conversational tone", "college-student audience", "10 min total"))
                .guestIntroLine("Dr. Meera Sharma is an AI Research Lead at Apollo Hospitals who led India's first FDA-approved AI radiology tool.")
                .segmentPlan(List.of(
                        SegmentPlan.builder().name("Opening").minutes(2).objective("Hook the audience and introduce the guest").build(),
                        SegmentPlan.builder().name("Deep Dive").minutes(5).objective("Explore AI diagnostic accuracy and patient trust").build(),
                        SegmentPlan.builder().name("Closing").minutes(3).objective("Summarize key takeaways and inspire career interest").build()
                ))
                .build();

        ScriptAgent agent = new ScriptAgent(config);
        ScriptOutput result = agent.run(ctx);

        System.out.println("======================================================================");
        System.out.println("EPISODE TITLE: " + result.getEpisodeTitle());
        System.out.println("ESTIMATED DURATION: " + result.getEstimatedDuration() + " minutes");
        System.out.println("======================================================================");

        System.out.println("\n--- INTRO ---");
        System.out.println(result.getIntro());

        for (ScriptSegment seg : result.getSegments()) {
            System.out.println("\n--- SEGMENT: " + seg.getName() + " ---");
            for (String line : seg.getHostLines()) {
                System.out.println(line);
            }
            System.out.println("  >> " + seg.getTransition());
        }

        System.out.println("\n--- OUTRO ---");
        System.out.println(result.getOutro());
        System.out.println("======================================================================");
    }
}


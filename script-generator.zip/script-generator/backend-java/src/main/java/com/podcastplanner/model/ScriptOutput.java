package com.podcastplanner.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScriptOutput {

    @JsonProperty("episode_title")
    private String episodeTitle;

    @JsonProperty("intro")
    private String intro;

    @JsonProperty("segments")
    private List<ScriptSegment> segments;

    @JsonProperty("outro")
    private String outro;

    @JsonProperty("estimated_duration")
    private int estimatedDuration;
}


package com.podcastplanner.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class EpamDialConfig {

    @Value("${epam.dial.url}")
    private String url;

    @Value("${epam.dial.api-key}")
    private String apiKey;

    @Value("${epam.dial.model}")
    private String model;

    @Value("${script.temperature}")
    private double temperature;

    @Value("${script.max-tokens}")
    private int maxTokens;
}


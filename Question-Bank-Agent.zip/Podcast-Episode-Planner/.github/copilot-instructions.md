# GitHub Copilot Instructions — Podcast Episode Planner

## Project Overview
This is a **Java 25 Maven** application for planning and managing podcast episodes.
It covers episode scheduling, guest management, topic organization, and show notes.

## Architecture
Follow a layered package structure under `org.example`:
| Package | Purpose |
|---------|---------|
| `model` | Plain Java classes / records: `Episode`, `Guest`, `Topic`, `ShowNote`, `Series` |
| `repository` | In-memory or file-based data storage interfaces + implementations |
| `service` | Business logic: `EpisodeService`, `GuestService`, `TopicService` |
| `ui` | CLI entry point with numbered menus |
| `util` | Helper utilities: `DateUtils`, `ExportUtils`, `ValidationUtils` |

## Coding Conventions
- Java 25, Maven build (`pom.xml` at root)
- JUnit 5 for all tests (place in `src/test/java`)
- Use `Optional<T>` instead of returning `null`
- Validate all inputs in service methods; throw `IllegalArgumentException` for bad input
- Prefer Java **records** for immutable value objects
- Use **builder pattern** for objects with many optional fields
- Add Javadoc to every public class and method

## Key Domain Concepts
- **Episode**: title, description, recordingDate, publishDate, durationMinutes, status (`PLANNED`, `RECORDED`, `PUBLISHED`), guests, topics, showNotes
- **Guest**: name, bio, contactEmail, previousEpisodes
- **Topic**: name, description, tags
- **ShowNote**: episodeId, content, timestamp
- **Series**: name, description, list of episodes

## Do NOT
- Return raw `null` from service/repository methods
- Skip input validation
- Mix business logic into model classes
- Use System.exit() outside the main entry point


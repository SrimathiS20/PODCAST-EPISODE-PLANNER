# Podcast Episode Planner

Starter setup for secure API key wiring and EPAM DIAL question-bank generation with Java + Maven.

## Added Components
- `src/main/java/org/example/util/ApiKeyProvider.java`
- `src/main/java/org/example/model/DialConfig.java`
- `src/main/java/org/example/model/QuestionBankRequest.java`
- `src/main/java/org/example/service/DialQuestionBankService.java`
- `src/main/java/org/example/ui/ApiKeyCheckApp.java`
- `src/main/java/org/example/ui/DialQuestionBankApp.java`
- `src/test/java/org/example/util/ApiKeyProviderTest.java`
- `src/test/java/org/example/service/DialQuestionBankServiceTest.java`

## Local Setup
1. Copy `.env.example` to `.env`.
2. Fill `.env` with your values:
   - `DIAL_API_URL` (e.g. `https://ai-proxy.lab.epam.com/openai/deployments`)
   - `DIAL_API_KEY`
   - `DIAL_MODEL` (optional, defaults to `gpt-4o` in code)
3. Keep `.env` local only (already ignored by `.gitignore`).

## Run Tests
```powershell
mvn test
```

## Verify Key Loading
```powershell
mvn -q -DskipTests compile
java -cp target/classes org.example.ui.ApiKeyCheckApp
```

## Generate Question Bank via EPAM DIAL
```powershell
mvn -q -DskipTests compile
java -cp target/classes org.example.ui.DialQuestionBankApp "AI in Podcasting" "Guest Interview" 10 "Casual, emotional" 20
```

The app prints the generated question bank returned by DIAL.
If DIAL does not respond or returns an error, the app automatically prints a local fallback question bank.


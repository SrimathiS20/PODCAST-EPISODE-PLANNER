package org.example.ui;

import org.example.util.ApiKeyProvider;

/**
 * Tiny runner that verifies whether API key wiring is configured correctly.
 */
public final class ApiKeyCheckApp {

    private ApiKeyCheckApp() {
        // Utility class
    }

    /**
     * Entry point for local verification.
     *
     * @param args command line arguments
     */
    public static void main(final String[] args) {
        try {
            final String apiKey = ApiKeyProvider.getRequiredApiKey();
            System.out.println("API key loaded successfully: " + ApiKeyProvider.mask(apiKey));
            System.out.println("Do not print raw keys in logs.");
        } catch (IllegalStateException exception) {
            System.err.println(exception.getMessage());
            System.err.println("Tip: set API_KEY in your environment or .env (local only).");
            System.exit(1);
        }
    }
}


package org.example.ui;

import org.example.model.DialConfig;
import org.example.model.QuestionBankRequest;
import org.example.service.DialQuestionBankService;

/**
 * CLI entry point that calls EPAM DIAL and prints a generated question bank.
 */
public final class DialQuestionBankApp {

    private DialQuestionBankApp() {
        // Utility class
    }

    /**
     * Usage:
     * <pre>
     * java ... DialQuestionBankApp "Topic" "Format" 10 "Casual" 20
     * </pre>
     *
     * @param args topic, format, numberOfQuestions, tone, episodeDurationMinutes
     */
    public static void main(final String[] args) {
        if (args.length != 5) {
            System.err.println("Usage: DialQuestionBankApp <topic> <format> <numberOfQuestions> <tone> <episodeDurationMinutes>");
            System.exit(1);
        }

        try {
            final QuestionBankRequest request = new QuestionBankRequest(
                    args[0],
                    args[1],
                    Integer.parseInt(args[2]),
                    args[3],
                    Integer.parseInt(args[4])
            );

            final DialConfig config = DialConfig.fromEnvironment();
            final DialQuestionBankService service = new DialQuestionBankService();

            System.out.println("Calling DIAL with config: " + config.toSafeString());
            final String output = service.generateQuestionBankWithFallback(request, config);
            System.out.println("\n--- Generated Question Bank ---\n");
            if (output.startsWith("# Fallback Question Bank")) {
                System.out.println("[INFO] API unavailable. Fallback output generated.\n");
            } else {
                System.out.println("[INFO] API response received.\n");
            }
            System.out.println(output);
        } catch (NumberFormatException exception) {
            System.err.println("numberOfQuestions and episodeDurationMinutes must be integers");
            System.exit(1);
        } catch (RuntimeException exception) {
            System.err.println("Failed to generate question bank: " + exception.getMessage());
            System.exit(1);
        }
    }
}


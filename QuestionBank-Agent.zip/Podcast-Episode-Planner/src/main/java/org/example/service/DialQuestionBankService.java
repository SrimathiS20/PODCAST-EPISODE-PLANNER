package org.example.service;

import org.example.model.DialConfig;
import org.example.model.QuestionBankRequest;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * Calls EPAM DIAL API to generate a podcast question bank.
 */
public class DialQuestionBankService {

    private static final String SYSTEM_PROMPT = "You are a Question Bank Creation Assistant for podcast planners. "
            + "Generate comprehensive, categorized, and engaging question banks. "
            + "Return markdown with headings, follow-up prompts, timings, and host tips.";

    private final HttpClient httpClient;

    /**
     * Creates a service with default HTTP client.
     */
    public DialQuestionBankService() {
        this(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build());
    }

    /**
     * Creates a service with an injected HTTP client.
     *
     * @param httpClient HTTP client instance
     */
    public DialQuestionBankService(final HttpClient httpClient) {
        if (httpClient == null) {
            throw new IllegalArgumentException("httpClient must not be null");
        }
        this.httpClient = httpClient;
    }

    /**
     * Generates a question bank by calling the DIAL chat completion endpoint.
     *
     * @param request user request
     * @param config DIAL configuration
     * @return generated question bank markdown
     */
    public String generateQuestionBank(final QuestionBankRequest request, final DialConfig config) {
        if (request == null) {
            throw new IllegalArgumentException("request must not be null");
        }
        if (config == null) {
            throw new IllegalArgumentException("config must not be null");
        }

        final String requestBody = buildRequestBody(request, config.model());

        final HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(resolveEndpoint(config.apiUrl(), config.model())))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + config.apiKey())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            final HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() >= 400) {
                throw new IllegalStateException("DIAL API request failed with status " + response.statusCode()
                        + ". Body: " + response.body());
            }
            return extractAssistantContent(response.body());
        } catch (IOException exception) {
            throw new IllegalStateException("DIAL API call failed due to I/O error", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("DIAL API call was interrupted", exception);
        }
    }

    /**
     * Generates a question bank using DIAL API first, then falls back locally when API fails.
     *
     * @param request user request
     * @param config DIAL configuration
     * @return generated question bank markdown from API or local fallback
     */
    public String generateQuestionBankWithFallback(final QuestionBankRequest request, final DialConfig config) {
        try {
            return generateQuestionBank(request, config);
        } catch (RuntimeException exception) {
            return generateFallbackQuestionBank(request, exception.getMessage());
        }
    }

    static String resolveEndpoint(final String apiUrl, final String model) {
        if (apiUrl == null || apiUrl.isBlank()) {
            throw new IllegalArgumentException("apiUrl must not be null or blank");
        }
        if (model == null || model.isBlank()) {
            throw new IllegalArgumentException("model must not be null or blank");
        }

        if (apiUrl.contains("/chat/completions")) {
            return apiUrl;
        }

        final String normalizedUrl = apiUrl.endsWith("/") ? apiUrl.substring(0, apiUrl.length() - 1) : apiUrl;
        final String encodedModel = URLEncoder.encode(model, StandardCharsets.UTF_8);
        return normalizedUrl + "/" + encodedModel + "/chat/completions";
    }

    static String generateFallbackQuestionBank(final QuestionBankRequest request, final String failureReason) {
        final int questionCount = Math.max(1, request.numberOfQuestions());
        final int perQuestionMinutes = Math.max(1, request.episodeDurationMinutes() / questionCount);

        final StringBuilder output = new StringBuilder();
        output.append("# Fallback Question Bank\n")
                .append("Topic: ").append(request.topic()).append("\n")
                .append("Format: ").append(request.format()).append("\n")
                .append("Tone: ").append(request.tone()).append("\n")
                .append("Estimated duration: ").append(request.episodeDurationMinutes()).append(" minutes\n\n")
                .append("_Note: DIAL API was unavailable. Showing local fallback._\n")
                .append("_Reason: ").append(failureReason == null ? "unknown" : failureReason).append("_\n\n");

        for (int index = 1; index <= questionCount; index++) {
            output.append(index)
                    .append(". [guest interview] ")
                    .append("What is your perspective on ")
                    .append(request.topic())
                    .append(" (part ")
                    .append(index)
                    .append(")?\n")
                    .append("   - Follow-up: Can you share a concrete example?\n")
                    .append("   - Estimated response time: ~")
                    .append(perQuestionMinutes)
                    .append(" min\n");
        }

        output.append("\nBackup Questions:\n")
                .append("- What common misconception should listeners avoid?\n")
                .append("- What should listeners do next after this episode?\n");

        return output.toString();
    }

    static String buildRequestBody(final QuestionBankRequest request, final String model) {
        final String userPrompt = buildUserPrompt(request);

        return "{"
                + "\"model\":\"" + escapeJson(model) + "\","
                + "\"messages\":["
                + "{\"role\":\"system\",\"content\":\"" + escapeJson(SYSTEM_PROMPT) + "\"},"
                + "{\"role\":\"user\",\"content\":\"" + escapeJson(userPrompt) + "\"}"
                + "],"
                + "\"temperature\":0.7"
                + "}";
    }

    static String buildUserPrompt(final QuestionBankRequest request) {
        return "Create a podcast question bank with these inputs:\n"
                + "Topic: " + request.topic() + "\n"
                + "Format: " + request.format() + "\n"
                + "Number of Questions: " + request.numberOfQuestions() + "\n"
                + "Tone: " + request.tone() + "\n"
                + "Episode Duration: " + request.episodeDurationMinutes() + " minutes\n\n"
                + "Requirements:\n"
                + "1) Include icebreaker, deep-dive, narrative, and reflective questions where relevant.\n"
                + "2) Add follow-up prompts and estimated time per question.\n"
                + "3) Keep questions open-ended and balanced.\n"
                + "4) Include 2 backup questions and host tips at the end.";
    }

    static String extractAssistantContent(final String responseBody) {
        if (responseBody == null || responseBody.isBlank()) {
            throw new IllegalStateException("DIAL API returned an empty response body");
        }

        final int choicesIndex = responseBody.indexOf("\"choices\"");
        final int messageIndex = responseBody.indexOf("\"message\"", Math.max(choicesIndex, 0));
        final int contentKeyIndex = responseBody.indexOf("\"content\"", Math.max(messageIndex, 0));
        if (contentKeyIndex < 0) {
            throw new IllegalStateException("DIAL API response does not contain assistant content");
        }

        final int firstQuote = responseBody.indexOf('"', responseBody.indexOf(':', contentKeyIndex));
        if (firstQuote < 0) {
            throw new IllegalStateException("Unable to parse assistant content from DIAL API response");
        }

        final StringBuilder encoded = new StringBuilder();
        boolean escaping = false;
        for (int i = firstQuote + 1; i < responseBody.length(); i++) {
            final char ch = responseBody.charAt(i);

            if (escaping) {
                encoded.append(ch);
                escaping = false;
                continue;
            }

            if (ch == '\\') {
                escaping = true;
                encoded.append(ch);
                continue;
            }

            if (ch == '"') {
                return unescapeJsonString(encoded.toString());
            }

            encoded.append(ch);
        }

        throw new IllegalStateException("Unable to parse assistant content from DIAL API response");
    }

    private static String escapeJson(final String value) {
        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n");
    }

    private static String unescapeJsonString(final String value) {
        return value
                .replace("\\n", "\n")
                .replace("\\\"", "\"")
                .replace("\\\\", "\\");
    }
}


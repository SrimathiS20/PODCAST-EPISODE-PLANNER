package org.example.model;

/**
 * Input fields used to generate a podcast question bank.
 *
 * @param topic podcast topic
 * @param format episode format
 * @param numberOfQuestions number of questions requested
 * @param tone requested tone
 * @param episodeDurationMinutes target episode duration in minutes
 */
public record QuestionBankRequest(
        String topic,
        String format,
        int numberOfQuestions,
        String tone,
        int episodeDurationMinutes
) {

    /**
     * Validates required request values.
     */
    public QuestionBankRequest {
        if (topic == null || topic.isBlank()) {
            throw new IllegalArgumentException("topic must not be null or blank");
        }
        if (format == null || format.isBlank()) {
            throw new IllegalArgumentException("format must not be null or blank");
        }
        if (numberOfQuestions <= 0) {
            throw new IllegalArgumentException("numberOfQuestions must be greater than 0");
        }
        if (tone == null || tone.isBlank()) {
            throw new IllegalArgumentException("tone must not be null or blank");
        }
        if (episodeDurationMinutes <= 0) {
            throw new IllegalArgumentException("episodeDurationMinutes must be greater than 0");
        }
    }
}


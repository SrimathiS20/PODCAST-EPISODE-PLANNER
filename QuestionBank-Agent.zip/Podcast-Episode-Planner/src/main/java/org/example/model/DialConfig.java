package org.example.model;

import org.example.util.ApiKeyProvider;

/**
 * Runtime configuration for EPAM DIAL chat-completions requests.
 *
 * @param apiUrl full DIAL chat-completions API URL
 * @param apiKey bearer token
 * @param model model name recognized by DIAL
 */
public record DialConfig(String apiUrl, String apiKey, String model) {

    /**
     * Environment variable for DIAL endpoint URL.
     */
    public static final String DIAL_API_URL_ENV = "DIAL_API_URL";

    /**
     * Environment variable for DIAL API key.
     */
    public static final String DIAL_API_KEY_ENV = "DIAL_API_KEY";

    /**
     * Environment variable for DIAL model identifier.
     */
    public static final String DIAL_MODEL_ENV = "DIAL_MODEL";

    /**
     * Backward-compatible generic API key variable.
     */
    public static final String FALLBACK_API_KEY_ENV = "API_KEY";

    /**
     * Default model used when DIAL_MODEL is not configured.
     */
    public static final String DEFAULT_MODEL = "gpt-4o";

    /**
     * Validates config values.
     */
    public DialConfig {
        if (apiUrl == null || apiUrl.isBlank()) {
            throw new IllegalArgumentException("apiUrl must not be null or blank");
        }
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalArgumentException("apiKey must not be null or blank");
        }
        if (model == null || model.isBlank()) {
            throw new IllegalArgumentException("model must not be null or blank");
        }
    }

    /**
     * Loads required DIAL configuration from environment and optional .env file.
     *
     * @return validated DIAL config
     */
    public static DialConfig fromEnvironment() {
        final String apiUrl = ApiKeyProvider.getRequiredValue(DIAL_API_URL_ENV);
        final String apiKey = ApiKeyProvider.findValue(DIAL_API_KEY_ENV)
                .or(() -> ApiKeyProvider.findValue(FALLBACK_API_KEY_ENV))
                .orElseThrow(() -> new IllegalStateException(
                        "Missing DIAL API key. Set DIAL_API_KEY (or API_KEY) in environment or .env."
                ));

        final String model = ApiKeyProvider.findValue(DIAL_MODEL_ENV).orElse(DEFAULT_MODEL);
        return new DialConfig(apiUrl, apiKey, model);
    }

    /**
     * Returns a safe one-line representation for logs.
     *
     * @return masked config representation
     */
    public String toSafeString() {
        return "DialConfig{apiUrl='" + apiUrl + "', apiKey='" + ApiKeyProvider.mask(apiKey)
                + "', model='" + model + "'}";
    }
}


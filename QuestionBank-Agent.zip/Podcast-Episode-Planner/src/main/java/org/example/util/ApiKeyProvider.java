package org.example.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Optional;

/**
 * Resolves application secrets from safe local sources.
 *
 * <p>Resolution order:</p>
 * <ol>
 *   <li>Environment variable by name</li>
 *   <li>Local {@code .env} file in the working directory</li>
 * </ol>
 */
public final class ApiKeyProvider {

    /** Environment variable name used by the application. */
    public static final String API_KEY_ENV_NAME = "API_KEY";

    private ApiKeyProvider() {
        // Utility class
    }

    /** Default local .env file path. */
    public static final Path DEFAULT_DOT_ENV_PATH = Path.of(".env");

    /**
     * Finds a variable value using process environment values and local {@code .env} fallback.
     *
     * @param variableName variable name to resolve
     * @return optional value when available and non-blank
     */
    public static Optional<String> findValue(final String variableName) {
        return findValue(variableName, System.getenv(), DEFAULT_DOT_ENV_PATH);
    }

    /**
     * Finds a variable value with explicit environment map and .env path.
     *
     * @param variableName variable name to resolve
     * @param environment process-like environment values
     * @param dotEnvPath path to the optional .env file
     * @return optional value when available and non-blank
     * @throws IllegalArgumentException when inputs are null/blank
     */
    public static Optional<String> findValue(
            final String variableName,
            final Map<String, String> environment,
            final Path dotEnvPath
    ) {
        if (variableName == null || variableName.isBlank()) {
            throw new IllegalArgumentException("variableName must not be null or blank");
        }
        if (environment == null) {
            throw new IllegalArgumentException("environment must not be null");
        }
        if (dotEnvPath == null) {
            throw new IllegalArgumentException("dotEnvPath must not be null");
        }

        final Optional<String> fromEnvironment = sanitize(environment.get(variableName));
        if (fromEnvironment.isPresent()) {
            return fromEnvironment;
        }

        return readFromDotEnv(dotEnvPath, variableName);
    }

    /**
     * Finds an API key using process environment values and local {@code .env} fallback.
     *
     * @return optional API key value when available and non-blank
     */
    public static Optional<String> findApiKey() {
        return findValue(API_KEY_ENV_NAME);
    }

    /**
     * Finds an API key with explicit environment map and .env path.
     *
     * @param environment process-like environment values
     * @param dotEnvPath path to the optional .env file
     * @return optional API key value when available and non-blank
     * @throws IllegalArgumentException when inputs are null
     */
    public static Optional<String> findApiKey(final Map<String, String> environment, final Path dotEnvPath) {
        return findValue(API_KEY_ENV_NAME, environment, dotEnvPath);
    }

    /**
     * Resolves and returns API key or throws when missing.
     *
     * @return non-blank API key
     * @throws IllegalStateException when key is unavailable
     */
    public static String getRequiredApiKey() {
        return getRequiredValue(API_KEY_ENV_NAME);
    }

    /**
     * Resolves and returns a required variable or throws when missing.
     *
     * @param variableName variable name to resolve
     * @return non-blank value
     * @throws IllegalArgumentException when variableName is null/blank
     * @throws IllegalStateException when value is unavailable
     */
    public static String getRequiredValue(final String variableName) {
        return findValue(variableName).orElseThrow(() -> new IllegalStateException(
                "Missing required variable " + variableName + ". Set it in environment or create a local .env file."
        ));
    }

    /**
     * Resolves and returns a required variable or throws when missing.
     *
     * @param variableName variable name to resolve
     * @param environment process-like environment values
     * @param dotEnvPath path to the optional .env file
     * @return non-blank value
     * @throws IllegalArgumentException when inputs are null/blank
     * @throws IllegalStateException when value is unavailable
     */
    public static String getRequiredValue(
            final String variableName,
            final Map<String, String> environment,
            final Path dotEnvPath
    ) {
        return findValue(variableName, environment, dotEnvPath).orElseThrow(() -> new IllegalStateException(
                "Missing required variable " + variableName + ". Set it in environment or create a local .env file."
        ));
    }

    /**
     * Resolves and returns API key or throws when missing.
     *
     * @param environment process-like environment values
     * @param dotEnvPath path to the optional .env file
     * @return non-blank API key
     * @throws IllegalArgumentException when inputs are null
     * @throws IllegalStateException when key is unavailable
     */
    public static String getRequiredApiKey(final Map<String, String> environment, final Path dotEnvPath) {
        return findApiKey(environment, dotEnvPath).orElseThrow(() -> new IllegalStateException(
                "Missing API key. Set API_KEY in environment or create a local .env file."
        ));
    }

    /**
     * Returns a masked representation suitable for logs.
     *
     * @param apiKey raw key value
     * @return masked key preview
     * @throws IllegalArgumentException when key is null or blank
     */
    public static String mask(final String apiKey) {
        final String cleanKey = sanitize(apiKey)
                .orElseThrow(() -> new IllegalArgumentException("apiKey must not be null or blank"));

        if (cleanKey.length() <= 4) {
            return "****";
        }

        return cleanKey.substring(0, 2) + "..." + cleanKey.substring(cleanKey.length() - 2);
    }

    private static Optional<String> readFromDotEnv(final Path dotEnvPath, final String variableName) {
        if (!Files.exists(dotEnvPath)) {
            return Optional.empty();
        }

        try {
            for (String line : Files.readAllLines(dotEnvPath)) {
                final String trimmed = line.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                    continue;
                }

                final int separatorIndex = trimmed.indexOf('=');
                if (separatorIndex <= 0) {
                    continue;
                }

                final String key = trimmed.substring(0, separatorIndex).trim();
                if (!variableName.equals(key)) {
                    continue;
                }

                final String value = trimmed.substring(separatorIndex + 1).trim();
                return sanitize(value);
            }
        } catch (IOException ignored) {
            return Optional.empty();
        }

        return Optional.empty();
    }

    private static Optional<String> sanitize(final String value) {
        if (value == null) {
            return Optional.empty();
        }

        final String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return Optional.empty();
        }

        return Optional.of(trimmed);
    }
}


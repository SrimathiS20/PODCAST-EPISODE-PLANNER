package org.example.service;

import org.example.model.QuestionBankRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for {@link DialQuestionBankService} helpers.
 */
class DialQuestionBankServiceTest {

    @Test
    void buildRequestBodyContainsModelAndPromptData() {
        final QuestionBankRequest request = new QuestionBankRequest(
                "AI in Podcasting",
                "Guest Interview",
                5,
                "Casual",
                20
        );

        final String payload = DialQuestionBankService.buildRequestBody(request, "gpt-4o");

        assertTrue(payload.contains("\"model\":\"gpt-4o\""));
        assertTrue(payload.contains("AI in Podcasting"));
        assertTrue(payload.contains("Guest Interview"));
        assertTrue(payload.contains("Number of Questions: 5"));
    }

    @Test
    void extractAssistantContentParsesOpenAiStyleResponse() {
        final String response = "{\"id\":\"x\",\"choices\":[{\"index\":0,\"message\":{\"role\":\"assistant\",\"content\":\"# Heading\\nLine 2\"}}]}";

        final String content = DialQuestionBankService.extractAssistantContent(response);

        assertEquals("# Heading\nLine 2", content);
    }

    @Test
    void resolveEndpointAppendsModelAndCompletionsWhenBaseDeploymentsUrlProvided() {
        final String endpoint = DialQuestionBankService.resolveEndpoint(
                "https://ai-proxy.lab.epam.com/openai/deployments",
                "gpt-4o"
        );

        assertEquals("https://ai-proxy.lab.epam.com/openai/deployments/gpt-4o/chat/completions", endpoint);
    }

    @Test
    void generateQuestionBankWithFallbackReturnsLocalOutputWhenApiCallFails() {
        final DialQuestionBankService service = new DialQuestionBankService() {
            @Override
            public String generateQuestionBank(final QuestionBankRequest request, final org.example.model.DialConfig config) {
                throw new IllegalStateException("simulated API timeout");
            }
        };

        final QuestionBankRequest request = new QuestionBankRequest(
                "AI in Podcasting",
                "Guest Interview",
                3,
                "Casual",
                15
        );

        final String output = service.generateQuestionBankWithFallback(
                request,
                new org.example.model.DialConfig("https://example", "key", "gpt-4o")
        );

        assertTrue(output.startsWith("# Fallback Question Bank"));
        assertTrue(output.contains("simulated API timeout"));
        assertTrue(output.contains("AI in Podcasting"));
    }
}


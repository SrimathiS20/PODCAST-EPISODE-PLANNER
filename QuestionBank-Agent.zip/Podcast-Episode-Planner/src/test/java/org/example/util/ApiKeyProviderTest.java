package org.example.util;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for {@link ApiKeyProvider}.
 */
class ApiKeyProviderTest {

    @Test
    void findValueReadsNamedVariableFromDotEnv() throws IOException {
        final Path tempEnvFile = Files.createTempFile("named-var", ".env");
        Files.writeString(tempEnvFile, "DIAL_MODEL=gpt-4o\n");

        final var resolved = ApiKeyProvider.findValue("DIAL_MODEL", Map.of(), tempEnvFile);

        assertTrue(resolved.isPresent());
        assertEquals("gpt-4o", resolved.get());

        Files.deleteIfExists(tempEnvFile);
    }

    @Test
    void findApiKeyReturnsEnvironmentValueWhenPresent() throws IOException {
        final Path tempEnvFile = Files.createTempFile("apikey", ".env");
        Files.writeString(tempEnvFile, "API_KEY=from-file");

        final var resolved = ApiKeyProvider.findApiKey(Map.of("API_KEY", "from-env"), tempEnvFile);

        assertTrue(resolved.isPresent());
        assertEquals("from-env", resolved.get());

        Files.deleteIfExists(tempEnvFile);
    }

    @Test
    void findApiKeyFallsBackToDotEnv() throws IOException {
        final Path tempEnvFile = Files.createTempFile("apikey", ".env");
        Files.writeString(tempEnvFile, "# comment\nAPI_KEY=from-file\n");

        final var resolved = ApiKeyProvider.findApiKey(Map.of(), tempEnvFile);

        assertTrue(resolved.isPresent());
        assertEquals("from-file", resolved.get());

        Files.deleteIfExists(tempEnvFile);
    }

    @Test
    void getRequiredApiKeyThrowsWhenMissing() {
        final IllegalStateException exception = assertThrows(IllegalStateException.class,
                () -> ApiKeyProvider.getRequiredApiKey(Map.of(), Path.of("missing-file.env")));

        assertTrue(exception.getMessage().contains("Missing API key"));
    }

    @Test
    void maskReturnsSafePreview() {
        assertEquals("ab...34", ApiKeyProvider.mask("abcd1234"));
        assertEquals("****", ApiKeyProvider.mask("abcd"));
    }

    @Test
    void findApiKeyRejectsNullInputs() {
        assertThrows(IllegalArgumentException.class, () -> ApiKeyProvider.findApiKey(null, Path.of(".env")));
        assertThrows(IllegalArgumentException.class, () -> ApiKeyProvider.findApiKey(Map.of(), null));
    }

    @Test
    void findValueRejectsInvalidInputs() {
        assertThrows(IllegalArgumentException.class, () -> ApiKeyProvider.findValue("", Map.of(), Path.of(".env")));
        assertThrows(IllegalArgumentException.class, () -> ApiKeyProvider.findValue("DIAL_MODEL", null, Path.of(".env")));
        assertThrows(IllegalArgumentException.class, () -> ApiKeyProvider.findValue("DIAL_MODEL", Map.of(), null));
    }
}

